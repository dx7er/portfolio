---
name: Ali Taqi Wajid
avatar: /static/images/phlesh.jpg
occupation: DevSecOps Engineer
email: root@theflash2k.me
twitter: https://twitter.com/alitaqiwajid
linkedin: https://www.linkedin.com/in/ali-taqi-wajid
github: https://github.com/theflash2k
---

A Cyber Security graduate with an avid interest in creating and breaking things. A passionate programmer with several years of experience in:
- Python3
- C/C++
- Bash