# TheFlash2k Portfolio.

First of all, shoutout to [Timothy](https://github.com/timlrx) for this amazing [theme](https://github.com/timlrx/tailwind-nextjs-starter-blog).

---

I made minor changes according to my own needs. These include:

- Removing the `tags` page
- Changing the information inside the `about` page
- Adding posts within the `data/blog` folder
- Removed the footer

---
